
<?php
/* Some code on footer */
?>

</body>
</html>